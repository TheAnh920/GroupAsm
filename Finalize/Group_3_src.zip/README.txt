GitHub repository URL:
https://github.com/s3926080-RMIT/JavaProgrammingSem3.git

Link to video demonstration:
https://youtu.be/BlW6miEfNR4

Admin login credentials:
Username: admin
Password: 920
